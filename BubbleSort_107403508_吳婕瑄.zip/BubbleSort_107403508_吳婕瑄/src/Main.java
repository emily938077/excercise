/*
 * 107403508�d��ޱ ��ޤTA
  * �ʺA�Ƨǵ{��_Bubble Sort
  * jdk����15
  * �M�󦳥Ψ�JFreeChart�A�����bzip�ɤ�
 */
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.lang.reflect.InvocationTargetException;
import java.util.*;
import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;

import org.jfree.chart.*;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.NumberTickUnit;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;


public class Main extends JFrame {
	
	  private static final long serialVersionUID = 6294689542092367723L;  
	  private int[] randomNum;
	  private XYSeriesCollection dataset;
	  private XYSeries series1;
	  public Main(String title) {  
	    super(title);  
	  
	    // Create dataset  
	    XYDataset dataset = createDataset();  
	  
	    // Create chart  
	    JFreeChart chart = ChartFactory.createScatterPlot(  
	        "Algo_HW","Array", "Integer-Number(1~200)", dataset);  
	    
	      
	    //Changes background color  
	    XYPlot plot = (XYPlot)chart.getPlot();  
	    plot.setBackgroundPaint(new Color(255,228,196));  
	    /*ValueAxis axis = plot.getRangeAxis() ;
	    axis.setRange(0,200) ;
	    plot.setRangeAxis(axis);*/
	   
	    plot.getRangeAxis().setRange(0,200);
	    plot.getDomainAxis().setRange(0,199);
	    //plot.getRangeAxis().setTickMarkInsideLength(length);;
	    //numberaxis.setTickUnit(new NumberTickUnit(150)); */ 
	    
	   // ValueAxis domainAxis = plot.getDomainAxis(); 
	    NumberAxis numberaxis = (NumberAxis) plot.getRangeAxis();  
	    numberaxis.setTickUnit(new NumberTickUnit(10));  
	    plot.setDomainAxis(numberaxis);
	    
	    
	    
	    BorderLayout layout = new BorderLayout();
	    setLayout(layout);
	    // Create Panel  
	    ChartPanel panel = new ChartPanel(chart);  
	    //setContentPane(panel); 
	    add(panel,BorderLayout.CENTER);
	    
	    JPanel buttonpanel = new JPanel();
	    add(buttonpanel,BorderLayout.SOUTH);
	    
	    JButton sort = new JButton("sort");
	    buttonpanel.add(sort);
	    sort.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {
	    	Runnable runner = new Runnable(){
	    		int bignum;
	    		@Override
	    		public void run() {
	    			int count = 0;
	    			int length = randomNum.length;
	    		    int temp;
	    		    Boolean is_sorted;//�ΨӧP�_�Ʀr�ݤ��ݭn������m��flag
	    		     
	    		    
	    		    for(int i=0;i<length;i++){
	    		    	
	    		    	is_sorted = true;
	    		    	
	    		    	for(int j=0;j<length-1;j++){
	    		    	   
	    		    	   //��j�p,�e>�� ����
	    		    	   if(randomNum[j]>randomNum[j+1]){
	    		    		  bignum=j;
	    		    		  temp = randomNum[j];
	    		    		  randomNum[j] = randomNum[j+1];
	    		    		  randomNum[j+1] = temp; 
	    		    		  count++;
	    		    		  try {
								SwingUtilities.invokeAndWait(new Runnable(){

									  @Override
									  public void run() {
										  series1.updateByIndex(bignum, randomNum[bignum]);
										  series1.updateByIndex(bignum+1, randomNum[bignum+1]);
									
									  }//end run
								  });
							} catch (InvocationTargetException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}//end runnable
	    		    		  //try{Thread.sleep(1);}catch(Exception except){}
	    		    	   }//end if
	    		    	}//end for
	    		    }//end is_sort
	    		 	
	    		}//end run
	    	};//end runnable
	    	 new Thread(runner).start();
        }//end actionPerformed
       
	    
	    }); //end addactionlistener
	  }// end construct
   


    private XYDataset createDataset() {  
        dataset = new XYSeriesCollection();  
       
        series1 = new XYSeries("random_num");  
        Random r = new Random();
    	randomNum = new int[200];
    	for (int i=0; i<200; i++){
    		randomNum[i] = r.nextInt(200)+1;		// �N�H����(1-200)��J randomNum[i]
    		for (int j=0; j<i;){			// �P�e�ƦC����A�Y���ۦP�h�A���ü�
    			if (randomNum[j]==randomNum[i]){	
    				randomNum[i] = r.nextInt(200)+1;
    				j=0;			// �׭����s�üƫ�S���ͬۦP�Ʀr�A�Y�X�{���СA�j��q�Y�}�l���s����Ҧ���
    			}
    			else j++;			// �Y�������ƫh�U�@�Ӽ�
    		}
    	}
    	
    	for(int i=0; i<200; i++) {
    		series1.add(i, randomNum[i]);
    	}
        
        dataset.addSeries(series1);  
        
        return dataset;  
      }  
    
    public static void main(String args[]) {
        SwingUtilities.invokeLater(new Runnable() {

            @Override
            public void run() {
                Main example = new Main("Algo_Bubble Sort");  
                example.setSize(800, 800);  
                example.setLocationRelativeTo(null);  
                example.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);  
                example.setVisible(true);
            }
        });
    }
}